create function updateunreadcount() returns trigger
    language plpgsql
as
$$
begin
    if (tg_op = 'INSERT') then
        if (new.status = 0) then
            update users set unread_count = unread_count + 1 where id = new.accept_id;
        end if;
    elsif (tg_op = 'UPDATE') then
        if (old.status = 0 and new.status != 0) then
            update users set unread_count = unread_count - 1 where id = new.accept_id;
        elsif (old.status != 0 and new.status = 0) then
            update users set unread_count = unread_count + 1 where id = new.accept_id;
        end if;

 
    elsif (tg_op = 'DELETE') then
        if (old.status = 0) then
            update users set unread_count = unread_count - 1 where id = old.accept_id;
        end if;
				RETURN OLD;
    end if;
		RETURN NEW;
    
end;
$$;

alter function updateunreadcount() owner to night;

