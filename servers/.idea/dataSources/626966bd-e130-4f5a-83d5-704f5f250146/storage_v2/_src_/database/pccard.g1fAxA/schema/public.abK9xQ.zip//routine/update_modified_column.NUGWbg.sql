create function update_modified_column() returns trigger
    language plpgsql
as
$$
begin
    new.updated_at = now();
    return new;
end;
$$;

alter function update_modified_column() owner to night;

